# Real-Time Traffic Prediction System

## Overview
This project predicts traffic congestion using machine learning and shows results in a Streamlit dashboard.

## Tech Stack
Python, Pandas, Scikit-learn, Streamlit

## How to Run
pip install -r requirements.txt  
streamlit run app.py

## Author
ML Internship Project
