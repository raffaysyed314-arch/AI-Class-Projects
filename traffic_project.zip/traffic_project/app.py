import streamlit as st
import pandas as pd

df = pd.read_csv("Metro_Interstate_Traffic_Volume.csv")

st.title("Real-Time Traffic Prediction System")

st.line_chart(df['traffic_volume'])

st.write("Anomaly Points")

from sklearn.ensemble import IsolationForest
iso = IsolationForest(contamination=0.01)
df['anomaly'] = iso.fit_predict(df[['traffic_volume']])

st.write(df[df['anomaly']==-1].head())
