
# NeuroPredict - Brain-Computer Interface for Motor Control

## Project Goal
Develop a BCI system to predict and classify motor intentions from EEG signals.

## Dataset
- EEG Motor Movement/Imagery Dataset (PhysioNet)
- Files used: S001R03, S001R04, S002R03, S002R04, S002R05, S002R06
- EEG signals recorded from 64 channels

## Steps Taken
1. Loaded EEG data using MNE library
2. Preprocessed signals (normalization, filtering)
3. Split data into training and validation sets
4. Built deep learning model (CNN/LSTM)
5. Trained model with early stopping to prevent overfitting
6. Predicted motor intentions (class labels)

## Results
- Training Accuracy: ~65%
- Validation Accuracy: ~72%
- Model file: NeuroPredict_model.keras

## How to Run
1. Load the trained model using TensorFlow/Keras
2. Preprocess new EEG data same as training
3. Use `model.predict()` to get motor intention predictions
