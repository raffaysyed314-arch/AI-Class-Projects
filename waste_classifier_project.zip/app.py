import streamlit as st
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import numpy as np
from PIL import Image

# Load trained model
model = load_model('waste_classifier.keras')

# Classes
classes = ['battery','biological','cardboard','clothes','glass','metal','paper','plastic','shoes','trash']

st.title("AI Waste Classifier ♻️")
st.write("Upload an image and the AI will tell the waste category.")

uploaded_file = st.file_uploader("Choose an image...", type=["jpg","png","jpeg"])

if uploaded_file is not None:
    img = Image.open(uploaded_file).convert('RGB')
    img = img.resize((160,160))
    st.image(img, caption='Uploaded Image', use_column_width=True)
    
    # Preprocess
    x = np.array(img)/255.0
    x = np.expand_dims(x, axis=0)
    
    # Predict
    preds = model.predict(x)
    class_idx = np.argmax(preds[0])
    st.success(f'Predicted Class: {classes[class_idx]}')
