# AI Waste Classifier

This is an AI-powered waste classification app.

## Features
- Classifies waste into 10 categories: battery, biological, cardboard, clothes, glass, metal, paper, plastic, shoes, trash.
- Built using TensorFlow MobileNetV2.
- Streamlit app for live image upload.
- Ngrok used for public URL deployment.

## How to Run
1. Install dependencies:
   pip install streamlit pyngrok tensorflow pillow
2. Run Streamlit app:
   streamlit run app.py
3. Open the public URL provided by ngrok.
